--------------------------------------
Wrench\\Exception\\BadRequestException
--------------------------------------

.. php:namespace: Wrench\\Exception

.. php:class:: BadRequestException

    .. php:attr:: message

        protected

    .. php:attr:: code

        protected

    .. php:attr:: file

        protected

    .. php:attr:: line

        protected

    .. php:method:: __construct($message = null, $code = null, $previous = null)

        :param $message:
        :param $code:
        :type $previous: Exception
        :param $previous:

    .. php:method:: __clone()

    .. php:method:: getMessage()

    .. php:method:: getCode()

    .. php:method:: getFile()

    .. php:method:: getLine()

    .. php:method:: getTrace()

    .. php:method:: getPrevious()

    .. php:method:: getTraceAsString()

    .. php:method:: __toString()
