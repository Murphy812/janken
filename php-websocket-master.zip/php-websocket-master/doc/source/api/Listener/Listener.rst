--------------------------
Wrench\\Listener\\Listener
--------------------------

.. php:namespace: Wrench\\Listener

.. php:class:: Listener

    .. php:method:: listen(Server $server)

        :type $server: Server
        :param $server:
