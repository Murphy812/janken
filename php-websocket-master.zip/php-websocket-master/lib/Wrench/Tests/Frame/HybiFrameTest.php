<?php

namespace Wrench\Tests\Frame;

use Wrench\Frame\HybiFrame;
use Wrench\Tests\Frame\FrameTest;

class HybiFrameTest extends FrameTest
{
    protected function getClass()
    {
        return 'Wrench\Frame\HybiFrame';
    }
}