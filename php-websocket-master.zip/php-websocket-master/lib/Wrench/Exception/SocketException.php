<?php
namespace Wrench\Exception;

use Wrench\Exception\Exception as WrenchException;

class SocketException extends WrenchException
{
}
