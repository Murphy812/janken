# TODO

 - Unify the socket handling of `WebSocket\Client` with that of `Websocket\Socket`
 - Moar tests!